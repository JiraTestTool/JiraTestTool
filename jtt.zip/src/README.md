# gSheets2Jira
quickly create or update JIRA tables for test case steps

gSheets2Jira can
* Generate JIRA table markup from a Google Spreadsheet
* Import existing JIRA tables for easy editing within a spreadsheet

A project for Tapestry Solutions in SLO.

Authors:
Michael Fekadu, Jonathan Devera, Chris Toh 
